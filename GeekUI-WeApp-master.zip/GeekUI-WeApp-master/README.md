![image.png](https://upload-images.jianshu.io/upload_images/4240944-57fd676fc75469a9.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

## 极客学苑小程序

体验组件库示例 Demo

![image.png](https://upload-images.jianshu.io/upload_images/4240944-750bdfdf830551eb.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

* #### 分享样式一



![image.png](https://upload-images.jianshu.io/upload_images/4240944-2b329f29764d297d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

- #### 样式二



![image.png](https://upload-images.jianshu.io/upload_images/4240944-357cd0b159f91d81.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

- #### 样式三

- 

![image.png](https://upload-images.jianshu.io/upload_images/4240944-f6007419892a1269.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

