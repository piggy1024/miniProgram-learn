// pages/marquee/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bar: {
      text: '最新资讯：微软以75亿美元价格收购世界上最大的同性交友平台 Github，不知道这是否是一向封闭的微软拥抱开源的信号！',
      scrollable: true,
      textColor: '#fff',
      backgroundColor: '#707070'
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

})