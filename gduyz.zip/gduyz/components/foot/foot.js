// components/foot/foot.js
Component({
    /**
     * 组件的属性列表
     */
    properties: {
        news: {
            type: Boolean,
            default: false
        }
    },

    /**
     * 组件的初始数据
     */
    data: {
    },

    pageLifetimes: {
    },

    /**
     * 组件的方法列表
     */
    methods: {
    }
})
